Faculty Portal : 
-> Download and install Xampp, copy and paste all the front-end folders into htdocs folder under the Xampp folder where it is stored after installation.
-> Download and install MongoDB, create its server to check out the MongoDB's database privilages in the portal. 
-> Download and install Postgres, create account name "postgres" with password "1109", copy paste all the functions, schemas into it.
-> You will need to create the admin account from the back-end by insereting into the admin's table.
-> Now start the apache server and opent localhost on the browser.
-> Login as an Admin first, then you can create all other kind of accounts, and use it.

Features : 
-> A NoSQL part where a faculty can create his/her profile, which can be seen by any other but is editable only by the corresponding faculty.
-> Leave Application feature where a faculty can apply for a leave which goes through a proper path as decided by the Admin of the portal.
-> Project allotment feature, where a faculty can float a project, the project can be alloted budget and the PI's of the project can propose an application for expenses approval which again goes to proper paths for approval.