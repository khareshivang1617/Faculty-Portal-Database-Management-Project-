<?php
    echo "Welcome to the home page!!! <br>";
    echo '<a href="http://localhost/phpmongodb/LoginPortal.php">Login</a>';
    echo "<br>";
    echo '<a href="http://localhost/phpmongodb/GuestPortal.php">Guest Login</a>';
    echo "<br>";
    echo '<a href="http://localhost/phpmongodb/CreateAccount.php">Create Account</a>';
    echo "<br>";
?>