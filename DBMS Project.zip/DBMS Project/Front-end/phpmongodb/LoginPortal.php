<html>
<body>

<h1>Login Info</h1>
<form action="GetLoginDetails.php" method="post">
<b>Username : <b> <input type="text" name="username">
<b>Password : <b> <input type="password" name="password">
<br>
<input type="submit">
</form>

</body>
</html>

<?php

echo "<br><br>";
echo '<a href="http://localhost/phpmongodb/Homepage.php">Home</a>';

?>